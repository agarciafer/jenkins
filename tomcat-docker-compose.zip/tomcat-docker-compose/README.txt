Utilizamos esta configuracion para lanzar tomcat a traves de contenedore con docker-compose.

El las consolas de administracion de la instalacion de Tomcat utilizamos el usuario admin con el password 000000:

<user username="admin" password="000000" roles="admin-gui,manager-gui"/>